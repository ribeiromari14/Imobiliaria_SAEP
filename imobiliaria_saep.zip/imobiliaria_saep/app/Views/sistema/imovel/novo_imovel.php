<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>Novo imovel</title>
    </head>
    <body>
        <h1>Novo imovel</h1>
        <form action="<?= base_url('imovel/inserir') ?>" method="POST">
            <label>Nome:</label><br>
            <input type="text" id="nome" name="nome" placeholder="Nome..." required>

            <br><br>
            
            <label>Rua:</label><br>
            <input type="text" id="rua" name="rua" required>
            
            <br><br>

            <label>Cidade:</label><br>
            <input type="text" id="cidade" name="cidade" required>

            <br><br>

            <label>Valor:</label><br>
            <input type="text" id="valor" name="valor" required>

            <br><br>

            <label>Proprietário:</label><br>
            <select id="proprietario" name="proprietario" required>
                <option value="">Selecione um proprietário</option>
                <?php foreach($proprietario as $pro): ?>
                    <option value="<?= $pro['PRO_ID'] ?>">
                        <?= $pro['PRO_NOME'] ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <br><br>

            <input type="submit" id="cadastrar_imovel" name="cadastrar_imovel" value="Cadastrar">
        </form>
        <br>
        <a href="<?= base_url('imovel') ?>"><button>Voltar</button></a>
    </body>
</html>