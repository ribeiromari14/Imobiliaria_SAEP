<?php
//Rotas Públicas
// Rotas Login
$routes->get('/', 'LoginController::index');
$routes->get('login', 'LoginController::index');
$routes->post('login/autenticar', 'LoginController::autenticar');
$routes->get('logout', 'LoginController::logout');

//Rotas Protegidas
$routes->group('', ['filter' => 'auth'], function($routes){
    // Rota Inicio
    $routes->get('inicio', 'InicioController::index');

    // Rotas proprietario
    $routes->match(['get', 'post'], 'proprietario',  'proprietarioController::index');
    $routes->get('proprietario/novo',                'proprietarioController::novo');
    $routes->post('proprietario/inserir',            'proprietarioController::inserir');
    $routes->get('proprietario/editar/(:num)',       'proprietarioController::editar/$1');
    $routes->post('proprietario/atualizar/(:num)',   'proprietarioController::atualizar/$1');
    $routes->get('proprietario/excluir/(:num)',      'proprietarioController::excluir/$1');

    // Rotas imovel
    $routes->match(['get', 'post'], 'imovel',  'imovelController::index');
    $routes->get('imovel/novo',                'imovelController::novo');
    $routes->post('imovel/inserir',            'imovelController::inserir');
    $routes->get('imovel/editar/(:num)',       'imovelController::editar/$1');
    $routes->post('imovel/atualizar/(:num)',   'imovelController::atualizar/$1');
    $routes->get('imovel/excluir/(:num)',      'imovelController::excluir/$1');

    // Rotas Agendamento
    $routes->match(['get', 'post'], 'agendamento',     'AgendamentoController::index');
    $routes->get('agendamento/novo',                   'AgendamentoController::novo');
    $routes->post('agendamento/inserir',               'AgendamentoController::inserir');
    $routes->get('agendamento/editar/(:num)',          'AgendamentoController::editar/$1');
    $routes->post('agendamento/atualizar/(:num)',      'AgendamentoController::atualizar/$1');
    $routes->get('agendamento/excluir/(:num)',         'AgendamentoController::excluir/$1');
});